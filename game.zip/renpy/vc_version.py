branch = 'fix'
nightly = False
official = True
version = '8.2.1.24030407'
version_name = '64bit Sensation'
